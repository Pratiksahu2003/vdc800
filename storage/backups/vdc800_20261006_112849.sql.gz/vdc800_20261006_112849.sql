-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: vdc800
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `about_sections`
--

DROP TABLE IF EXISTS `about_sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `about_sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hero_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_description` text COLLATE utf8mb4_unicode_ci,
  `hero_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mission` text COLLATE utf8mb4_unicode_ci,
  `vision` text COLLATE utf8mb4_unicode_ci,
  `story` longtext COLLATE utf8mb4_unicode_ci,
  `sustainability` text COLLATE utf8mb4_unicode_ci,
  `cta_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_description` text COLLATE utf8mb4_unicode_ci,
  `cta_button_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_button_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about_sections`
--

LOCK TABLES `about_sections` WRITE;
/*!40000 ALTER TABLE `about_sections` DISABLE KEYS */;
INSERT INTO `about_sections` VALUES (1,'Building the backbone of digital Europe','VDC800 was founded on a simple belief: digital infrastructure should be reliable, secure, and ready to scale. From our headquarters in Oslo, we design and operate data centres that prove performance and operational excellence go hand in hand.',NULL,'To deliver world-class digital infrastructure, enabling organisations to grow their digital capabilities with predictable uptime, security, and connectivity.','A future where every byte processed in Europe is hosted in facilities that set the global standard for availability, efficiency, and operational discipline.','<p>VDC800 began in 2018 when a team of Nordic engineers recognised that the explosive growth of cloud computing demanded a new class of data centre operations. Rather than accept the status quo, they set out to prove that facilities could be both powerful and precise.</p><p>Our first facility in Oslo opened in 2020, immediately achieving a PUE of 1.15 — well below the industry average. Today, we operate across Scandinavia with a pipeline of new facilities, each designed to push the boundaries of what enterprise infrastructure can achieve.</p>','Operational excellence is not a feature at VDC800 — it is our foundation. We publish availability metrics, run 24/7 NOC coverage, and design every facility for concurrent maintainability, efficient cooling, and disciplined change control.','Join us in building the next chapter of digital infrastructure','Whether you need colocation, cloud connectivity, or a custom enterprise solution, our team is ready to help.','Contact Our Team','/contact','About VDC800 — Nordic Data Centres',NULL,NULL,'2026-09-09 15:33:49','2026-09-14 10:09:34');
/*!40000 ALTER TABLE `about_sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `about_values`
--

DROP TABLE IF EXISTS `about_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `about_values` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `about_values`
--

LOCK TABLES `about_values` WRITE;
/*!40000 ALTER TABLE `about_values` DISABLE KEYS */;
INSERT INTO `about_values` VALUES (1,'Integrity','We operate transparently, publish real metrics, and hold ourselves accountable to the commitments we make.','badge-check',1,1,'2026-09-09 15:33:49','2026-09-09 15:33:49'),(2,'Innovation','We continuously invest in cooling, power, and automation technologies that push efficiency boundaries.','lightbulb',2,1,'2026-09-09 15:33:49','2026-09-09 15:33:49'),(3,'Partnership','We work alongside our clients as long-term partners, not just vendors, to solve complex infrastructure challenges.','handshake',3,1,'2026-09-09 15:33:49','2026-09-09 15:33:49'),(4,'Stewardship','We treat the environments and communities where we operate as responsibilities, not resources to exploit.','globe',4,1,'2026-09-09 15:33:49','2026-09-09 15:33:49');
/*!40000 ALTER TABLE `about_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int NOT NULL DEFAULT '0',
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_categories`
--

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
INSERT INTO `blog_categories` VALUES (1,'Data Centre Insights','data-centre-insights','Facility design, operations, and Nordic infrastructure trends.',1,'published','2026-09-09 15:33:49','2026-09-09 15:33:49'),(2,'Operations','operations','Facility operations, PUE optimisation, and data centre best practices.',2,'published','2026-09-09 15:33:49','2026-09-14 10:08:31'),(3,'Cloud & Connectivity','cloud-connectivity','Hybrid cloud, cross-connects, and carrier-neutral networking.',3,'published','2026-09-09 15:33:49','2026-09-09 15:33:49'),(4,'Security & Compliance','security-compliance','security frameworks, physical security, and regulatory readiness.',4,'published','2026-09-09 15:33:49','2026-09-09 15:33:49'),(5,'Industry News','industry-news','Market updates and VDC800 announcements from across Northern Europe.',5,'published','2026-09-09 15:33:49','2026-09-09 15:33:49');
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_posts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `blog_category_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `body` longtext COLLATE utf8mb4_unicode_ci,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_posts_slug_unique` (`slug`),
  KEY `blog_posts_blog_category_id_foreign` (`blog_category_id`),
  CONSTRAINT `blog_posts_blog_category_id_foreign` FOREIGN KEY (`blog_category_id`) REFERENCES `blog_categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_posts`
--

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('vdc800-cache-317d8afb6e187ba3612a9e83a33aa5a732f9568a','i:1;',1789752455),('vdc800-cache-317d8afb6e187ba3612a9e83a33aa5a732f9568a:timer','i:1789752455;',1789752455),('vdc800-cache-87d62985688185f8eedfe305ca8d2858d7c62180','i:1;',1789479185),('vdc800-cache-87d62985688185f8eedfe305ca8d2858d7c62180:timer','i:1789479185;',1789479185),('vdc800-cache-site_settings_all','a:5:{s:7:\"company\";a:26:{s:2:\"id\";i:1;s:12:\"company_name\";s:22:\"VDC800 Private Limited\";s:10:\"short_name\";s:6:\"VDC800\";s:7:\"tagline\";s:16:\"IS FUTURE OF DCs\";s:11:\"description\";s:91:\"VDC800 designs, builds, and operates premium data centre facilities across Northern Europe.\";s:13:\"about_company\";s:288:\"Founded with a vision to deliver world-class digital infrastructure, VDC800 combines Nordic engineering excellence with enterprise-grade operations. Our facilities serve enterprises, cloud providers, and research institutions who demand reliability, security, and predictable performance.\";s:5:\"email\";s:18:\"support@VDC800.com\";s:5:\"phone\";s:16:\"+91 981 840 7014\";s:15:\"secondary_phone\";s:16:\"+91 998 005 7320\";s:7:\"address\";s:23:\"Udyog Vihar,  Sector 18\";s:4:\"city\";s:8:\"Gurugram\";s:5:\"state\";s:7:\"Haryana\";s:7:\"country\";s:5:\"India\";s:11:\"postal_code\";s:6:\"122017\";s:8:\"map_link\";s:41:\"https://maps.app.goo.gl/wkofND9CzrFgy24EA\";s:13:\"map_embed_url\";N;s:12:\"founded_year\";s:4:\"2026\";s:10:\"vat_number\";s:14:\"NO123456789MVA\";s:28:\"business_registration_number\";s:11:\"918 765 432\";s:4:\"logo\";s:53:\"branding/xHU1hc4Q6jEjj62ojqjor1Y3iHlFF8AbgEMcm3Lw.png\";s:9:\"logo_dark\";s:53:\"branding/yBeHj5sxOmt3Uu3uxrDxYIcyrQKLDK9FcfcvG50s.png\";s:10:\"logo_light\";s:53:\"branding/LaYsFxgOIcsuFJbf9OhjcyvKFe47c6OVrnjqb2yg.png\";s:7:\"favicon\";s:53:\"branding/9Mf334Dy0iOQLChvHNtFlwIt9HJcKSLVSdmAaJbW.png\";s:11:\"footer_logo\";s:53:\"branding/JndhOKY4V2rnrA4u8qpEFnyYJvSu8dtxgc2aOcLT.png\";s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-22T18:34:11.000000Z\";}s:8:\"branding\";a:5:{s:4:\"logo\";s:53:\"branding/xHU1hc4Q6jEjj62ojqjor1Y3iHlFF8AbgEMcm3Lw.png\";s:9:\"logo_dark\";s:53:\"branding/yBeHj5sxOmt3Uu3uxrDxYIcyrQKLDK9FcfcvG50s.png\";s:10:\"logo_light\";s:53:\"branding/LaYsFxgOIcsuFJbf9OhjcyvKFe47c6OVrnjqb2yg.png\";s:7:\"favicon\";s:53:\"branding/9Mf334Dy0iOQLChvHNtFlwIt9HJcKSLVSdmAaJbW.png\";s:11:\"footer_logo\";s:53:\"branding/JndhOKY4V2rnrA4u8qpEFnyYJvSu8dtxgc2aOcLT.png\";}s:7:\"website\";a:13:{s:2:\"id\";i:1;s:12:\"website_name\";s:6:\"VDC800\";s:11:\"website_url\";s:22:\"https://www.vdc800.com\";s:18:\"default_page_title\";s:55:\"Data Center Planning, Design & Build Solutions | VDC800\";s:24:\"default_meta_description\";s:163:\"VDC800 provides end-to-end data center planning, design, engineering, build, commissioning and infrastructure support for secure, scalable and reliable facilities.\";s:16:\"default_keywords\";s:71:\"data centre, nordic, colocation, cloud connectivity, enterprise hosting\";s:19:\"google_analytics_id\";N;s:21:\"google_tag_manager_id\";N;s:8:\"timezone\";s:11:\"Europe/Oslo\";s:16:\"default_language\";s:2:\"en\";s:8:\"og_image\";N;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-14T15:13:43.000000Z\";}s:6:\"social\";a:6:{s:8:\"LinkedIn\";a:8:{s:2:\"id\";i:1;s:8:\"platform\";s:8:\"LinkedIn\";s:3:\"url\";s:35:\"https://linkedin.com/company/VDC800\";s:4:\"icon\";s:8:\"linkedin\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:1;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}s:1:\"X\";a:8:{s:2:\"id\";i:2;s:8:\"platform\";s:1:\"X\";s:3:\"url\";s:20:\"https://x.com/VDC800\";s:4:\"icon\";s:7:\"twitter\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:2;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}s:8:\"Facebook\";a:8:{s:2:\"id\";i:3;s:8:\"platform\";s:8:\"Facebook\";s:3:\"url\";s:27:\"https://facebook.com/VDC800\";s:4:\"icon\";s:8:\"facebook\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:3;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}s:9:\"Instagram\";a:8:{s:2:\"id\";i:4;s:8:\"platform\";s:9:\"Instagram\";s:3:\"url\";s:28:\"https://instagram.com/VDC800\";s:4:\"icon\";s:9:\"instagram\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:4;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}s:6:\"GitHub\";a:8:{s:2:\"id\";i:5;s:8:\"platform\";s:6:\"GitHub\";s:3:\"url\";s:25:\"https://github.com/VDC800\";s:4:\"icon\";s:6:\"github\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:5;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}s:7:\"YouTube\";a:8:{s:2:\"id\";i:6;s:8:\"platform\";s:7:\"YouTube\";s:3:\"url\";s:27:\"https://youtube.com/@VDC800\";s:4:\"icon\";s:7:\"youtube\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:6;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}}s:12:\"social_links\";a:6:{i:0;a:8:{s:2:\"id\";i:1;s:8:\"platform\";s:8:\"LinkedIn\";s:3:\"url\";s:35:\"https://linkedin.com/company/VDC800\";s:4:\"icon\";s:8:\"linkedin\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:1;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}i:1;a:8:{s:2:\"id\";i:2;s:8:\"platform\";s:1:\"X\";s:3:\"url\";s:20:\"https://x.com/VDC800\";s:4:\"icon\";s:7:\"twitter\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:2;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}i:2;a:8:{s:2:\"id\";i:3;s:8:\"platform\";s:8:\"Facebook\";s:3:\"url\";s:27:\"https://facebook.com/VDC800\";s:4:\"icon\";s:8:\"facebook\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:3;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}i:3;a:8:{s:2:\"id\";i:4;s:8:\"platform\";s:9:\"Instagram\";s:3:\"url\";s:28:\"https://instagram.com/VDC800\";s:4:\"icon\";s:9:\"instagram\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:4;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}i:4;a:8:{s:2:\"id\";i:5;s:8:\"platform\";s:6:\"GitHub\";s:3:\"url\";s:25:\"https://github.com/VDC800\";s:4:\"icon\";s:6:\"github\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:5;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}i:5;a:8:{s:2:\"id\";i:6;s:8:\"platform\";s:7:\"YouTube\";s:3:\"url\";s:27:\"https://youtube.com/@VDC800\";s:4:\"icon\";s:7:\"youtube\";s:9:\"is_active\";b:1;s:10:\"sort_order\";i:6;s:10:\"created_at\";s:27:\"2026-09-09T15:33:42.000000Z\";s:10:\"updated_at\";s:27:\"2026-09-09T15:33:42.000000Z\";}}}',1791284657);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_settings`
--

DROP TABLE IF EXISTS `company_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tagline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `about_company` longtext COLLATE utf8mb4_unicode_ci,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `map_link` text COLLATE utf8mb4_unicode_ci,
  `map_embed_url` text COLLATE utf8mb4_unicode_ci,
  `founded_year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vat_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_registration_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_dark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo_light` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_settings`
--

LOCK TABLES `company_settings` WRITE;
/*!40000 ALTER TABLE `company_settings` DISABLE KEYS */;
INSERT INTO `company_settings` VALUES (1,'VDC800 Private Limited','VDC800','IS FUTURE OF DCs','VDC800 designs, builds, and operates premium data centre facilities across Northern Europe.','Founded with a vision to deliver world-class digital infrastructure, VDC800 combines Nordic engineering excellence with enterprise-grade operations. Our facilities serve enterprises, cloud providers, and research institutions who demand reliability, security, and predictable performance.','support@VDC800.com','+91 981 840 7014','+91 998 005 7320','Udyog Vihar,  Sector 18','Gurugram','Haryana','India','122017','https://maps.app.goo.gl/wkofND9CzrFgy24EA',NULL,'2026','NO123456789MVA','918 765 432','branding/xHU1hc4Q6jEjj62ojqjor1Y3iHlFF8AbgEMcm3Lw.png','branding/yBeHj5sxOmt3Uu3uxrDxYIcyrQKLDK9FcfcvG50s.png','branding/LaYsFxgOIcsuFJbf9OhjcyvKFe47c6OVrnjqb2yg.png','branding/9Mf334Dy0iOQLChvHNtFlwIt9HJcKSLVSdmAaJbW.png','branding/JndhOKY4V2rnrA4u8qpEFnyYJvSu8dtxgc2aOcLT.png','2026-09-09 15:33:42','2026-09-22 18:34:11');
/*!40000 ALTER TABLE `company_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_submissions`
--

DROP TABLE IF EXISTS `contact_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_submissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `project_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('new','contacted','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_submissions`
--

LOCK TABLES `contact_submissions` WRITE;
/*!40000 ALTER TABLE `contact_submissions` DISABLE KEYS */;
INSERT INTO `contact_submissions` VALUES (1,'Erik Johansson','Nordic Fintech AS','erik.johansson@nordicfintech.no','+47 900 00 001','Colocation','We are looking for 20kW of colocation space with direct AWS connectivity. Could you provide availability and pricing for your Oslo facility?','new','2026-09-09 15:33:49','2026-09-09 15:33:49'),(2,'Anna Lindström','Uppsala University','anna.lindstrom@uu.se','+46 70 000 0002','HPC','Our research group needs high-density compute capacity for climate modelling. Interested in learning about your HPC solutions and academic pricing.','contacted','2026-09-09 15:33:49','2026-09-09 15:33:49'),(3,'Davidunurf','google','no.reply.MarcDavid@gmail.com','85462457765','Cloud Infrastructure','Hi! vdc800.com, \r\nI discovered vdc800.com while browsing different sites. \r\nOur service helps companies reach new partners through website contact pages. \r\nCompanies often use website communication to present their offers. \r\nWe offer simple and transparent pricing for the platform. \r\nYou can try the service for free to see how it works. \r\nIf you would like additional details, you can contact us. \r\n \r\nHope you have a great day. \r\nContact us. \r\nTelegram - https://t.me/FeedbackFormEU \r\nWhatsApp - +375259112693 \r\nWhatsApp  https://wa.me/+375259112693 \r\nWe only use chat for communication.','new','2026-09-17 02:05:33','2026-09-17 02:05:33'),(4,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:10:01','2026-09-18 22:10:01'),(5,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:10:14','2026-09-18 22:10:14'),(6,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:10:26','2026-09-18 22:10:26'),(7,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:10:46','2026-09-18 22:10:46'),(8,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:10:58','2026-09-18 22:10:58'),(9,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:11:07','2026-09-18 22:11:07'),(10,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:11:25','2026-09-18 22:11:25'),(11,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:11:44','2026-09-18 22:11:44'),(12,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:11:56','2026-09-18 22:11:56'),(13,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:12:12','2026-09-18 22:12:12'),(14,'lvfmqdsrti','ospnkkkyfl','zftueign@formtests.info','+1-161-877-4575','Select a project type','dmzrgszrjndufrrzsxxhinyrpwvvqi','new','2026-09-18 22:12:28','2026-09-18 22:12:28'),(15,'Deana Sam','Web Search Index','domains@search-vdc800.com','682678492','Cloud Infrastructure','Greetings\r\n\r\nAdd vdc800.com in Google\'s Search Index to be displayed in Google search results!\r\n\r\nAdd vdc800.com here:\r\n\r\nsearchindex.net','new','2026-09-22 19:30:03','2026-09-22 19:30:03'),(16,'Davidunurf','google','no.reply.Lars-OlofPeeters@gmail.com','86814983151','Cloud Infrastructure','Hello there! \r\nI came across your website and thought I would reach out. \r\nWe provide a tool for business outreach through website contact forms. \r\n You can try our service for free with up to 50,000 messages. \r\nIt costs $59 to send one million messages. \r\nContact us via chat if you would like to know more. \r\n \r\nThank you for taking the time to read this. \r\nTelegram - https://t.me/FeedbackFormEU \r\nWhatsApp - https://wa.me/375259112693 \r\nWe use chat exclusively for communication.','new','2026-09-27 12:59:09','2026-09-27 12:59:09'),(17,'Joanna Riggs','Dane Hocking','joannariggs3@gmail.com','3618474718','Other','Hi,\r\n\r\nI just visited vdc800.com and wondered if you\'ve ever considered an impactful video to advertise your business? Our videos can generate impressive results on both your website and across social media.\r\n\r\nOur videos cost just $195 (USD) for a 30 second video ($239 for 60 seconds) and include a full script, voice-over and video.\r\n\r\nI can show you some previous videos we\'ve done if you want me to send some over. Let me know if you\'re interested in seeing samples of our previous work.\r\n\r\nRegards,\r\nJoanna','new','2026-09-28 05:28:11','2026-09-28 05:28:11'),(18,'Leah Nunley','Web Search Index','domains@search-vdc800.com','51692949','Sustainability Consultation','Hey\r\n\r\nFeature vdc800.com in Google\'s Search Index to be visible in Google search results!\r\n\r\nFeature vdc800.com today: searchregister.net','new','2026-10-01 17:01:48','2026-10-01 17:01:48');
/*!40000 ALTER TABLE `contact_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_centre_features`
--

DROP TABLE IF EXISTS `data_centre_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_centre_features` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data_centre_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_centre_features_data_centre_id_foreign` (`data_centre_id`),
  CONSTRAINT `data_centre_features_data_centre_id_foreign` FOREIGN KEY (`data_centre_id`) REFERENCES `data_centres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_centre_features`
--

LOCK TABLES `data_centre_features` WRITE;
/*!40000 ALTER TABLE `data_centre_features` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_centre_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_centre_gallery`
--

DROP TABLE IF EXISTS `data_centre_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_centre_gallery` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data_centre_id` bigint unsigned NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `caption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alt_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_centre_gallery_data_centre_id_foreign` (`data_centre_id`),
  CONSTRAINT `data_centre_gallery_data_centre_id_foreign` FOREIGN KEY (`data_centre_id`) REFERENCES `data_centres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_centre_gallery`
--

LOCK TABLES `data_centre_gallery` WRITE;
/*!40000 ALTER TABLE `data_centre_gallery` DISABLE KEYS */;
INSERT INTO `data_centre_gallery` VALUES (1,4,'data-centre/gallery/jcAANiK8w3uoW3bto5HO2taBd1i0cXoGovHWXyBW.png',NULL,NULL,0,1,'2026-09-14 15:47:33','2026-09-14 15:47:33');
/*!40000 ALTER TABLE `data_centre_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_centre_specifications`
--

DROP TABLE IF EXISTS `data_centre_specifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_centre_specifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data_centre_id` bigint unsigned NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_centre_specifications_data_centre_id_foreign` (`data_centre_id`),
  CONSTRAINT `data_centre_specifications_data_centre_id_foreign` FOREIGN KEY (`data_centre_id`) REFERENCES `data_centres` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_centre_specifications`
--

LOCK TABLES `data_centre_specifications` WRITE;
/*!40000 ALTER TABLE `data_centre_specifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_centre_specifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_centres`
--

DROP TABLE IF EXISTS `data_centres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `data_centres` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `full_description` longtext COLLATE utf8mb4_unicode_ci,
  `hero_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_description` text COLLATE utf8mb4_unicode_ci,
  `cta_button_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_button_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'published',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `data_centres_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_centres`
--

LOCK TABLES `data_centres` WRITE;
/*!40000 ALTER TABLE `data_centres` DISABLE KEYS */;
INSERT INTO `data_centres` VALUES (4,'2.75 MVA Power Infrastructure','nordic-power','Critical power infrastructure',NULL,NULL,NULL,NULL,'Representative case-study framing. Client and project-identifying details are intentionally excluded.','2.75 MVA Power Infrastructure\r\n\r\nDelivering reliable and scalable power infrastructure for data center requirements up to 2.75 MVA. From technical capacity definition and electrical architecture to equipment selection, procurement coordination, and implementation planning, we provide end-to-end support for critical power systems. Our approach focuses on reliability, redundancy, protection, operational continuity, and future scalability—helping ensure your data center has a robust power foundation built for mission-critical workloads.','data-centre/0DYWa1qddOa9dcFARueqwmVvbKysC2mIOSjqXsKf.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'published',1,'2026-09-14 15:38:56','2026-09-14 15:55:47'),(5,'400 mm² Cable & Distribution Package','lv-infrastructure','LV infrastructure',NULL,NULL,NULL,NULL,'A high-current LV cable and distribution workstream focused on compliance, specification and sourcing.','400 mm² Cable & Distribution Package\r\n\r\nComprehensive cable and power distribution support for data center electrical infrastructure using 400 mm² cable systems. We provide technical specifications, cable sizing and routing guidance, distribution planning, equipment coordination, and procurement support to ensure efficient and reliable power delivery. The package is designed to support safe, scalable, and well-organized electrical distribution across critical data center loads.','data-centre/UGhSnqaYgvKkDpd6XZpTZ3Asf8YwEAA5vk9RP3A7.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'published',0,'2026-09-14 15:38:56','2026-09-14 16:16:13'),(6,'Data Center Feasibility & DPR','feasibility','Development advisory',NULL,NULL,NULL,NULL,'India-focused feasibility and DPR support for evaluating the commercial and technical path to a data center development.','Data Center Feasibility & DPR\r\n\r\nComprehensive Data Center Feasibility Study and Detailed Project Report (DPR) services to evaluate project viability, infrastructure requirements, investment considerations, and implementation strategy. We assess site suitability, power and cooling capacity, connectivity, space requirements, scalability, technical architecture, estimated costs, project timelines, and operational considerations to provide a clear roadmap for developing a reliable and future-ready data center.','data-centre/SyKuWChixHMuGqKxMRVTuIMb4WmlSwD28vSOFrC0.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'published',0,'2026-09-14 15:38:56','2026-09-14 16:18:45');
/*!40000 ALTER TABLE `data_centres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_benefits`
--

DROP TABLE IF EXISTS `homepage_benefits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homepage_benefits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_benefits`
--

LOCK TABLES `homepage_benefits` WRITE;
/*!40000 ALTER TABLE `homepage_benefits` DISABLE KEYS */;
INSERT INTO `homepage_benefits` VALUES (1,'High Availability','Tier IV design with concurrent maintainability and 99.999% uptime SLA.','activity',NULL,1,1,'2026-09-09 15:33:42','2026-09-15 13:58:43'),(2,'Ready for AI at Scale','Power, connectivity, and infrastructure designed to support the next generation of AI and high-performance computing.','brain-circuit',NULL,2,1,'2026-09-09 15:33:42','2026-09-16 06:03:27'),(3,'Carrier Neutral','Connect to 40+ carriers and cloud on-ramps from a single cross-connect.','network',NULL,3,1,'2026-09-09 15:33:42','2026-09-09 15:33:42'),(4,'Enterprise Security','Enterprise-grade with multi-layer physical and cyber security.','shield-check',NULL,4,1,'2026-09-09 15:33:42','2026-09-09 15:33:42');
/*!40000 ALTER TABLE `homepage_benefits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_hero_slides`
--

DROP TABLE IF EXISTS `homepage_hero_slides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homepage_hero_slides` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cta_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_hero_slides`
--

LOCK TABLES `homepage_hero_slides` WRITE;
/*!40000 ALTER TABLE `homepage_hero_slides` DISABLE KEYS */;
INSERT INTO `homepage_hero_slides` VALUES (1,'01','Data Center Planning & Consulting','Expert guidance from initial concept, feasibility, site selection, and capacity planning.','Video/home-hero.mp4','Read More','/services',1,1,'2026-09-09 15:33:42','2026-09-14 15:06:32'),(2,'02','Design & Infrastructure Engineering','Complete design support for power, cooling, networking, security, fire protection, and IT infrastructure.','Video/home-hero.mp4','Read More','/services',2,1,'2026-09-09 15:33:42','2026-09-14 15:06:32'),(3,'03','Data Center Build & Implementation','End-to-end support for construction, infrastructure installation, equipment deployment, and commissioning.','Video/home-hero.mp4','Read More','/services',3,1,'2026-09-09 15:33:42','2026-09-14 15:06:32'),(4,'04','Power, Cooling & Critical Systems','Design and implementation of reliable UPS, generators, electrical systems, cooling, monitoring, and redundancy.','Video/home-hero.mp4','Read More','/services',4,1,'2026-09-09 15:33:42','2026-09-14 15:06:32'),(5,'05','Testing, Commissioning & Operational Support','Comprehensive testing, system validation, commissioning, documentation, and ongoing technical support.','Video/home-hero.mp4','Read More','/services',5,1,'2026-09-09 15:33:42','2026-09-14 15:06:32');
/*!40000 ALTER TABLE `homepage_hero_slides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_settings`
--

DROP TABLE IF EXISTS `homepage_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homepage_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hero_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_subtitle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_description` text COLLATE utf8mb4_unicode_ci,
  `hero_background_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_cta_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_cta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_secondary_cta_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hero_secondary_cta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intro_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intro_description` text COLLATE utf8mb4_unicode_ci,
  `intro_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sustainability_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sustainability_description` text COLLATE utf8mb4_unicode_ci,
  `sustainability_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sustainability_cta_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sustainability_cta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infrastructure_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infrastructure_description` text COLLATE utf8mb4_unicode_ci,
  `infrastructure_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_cta_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_cta_description` text COLLATE utf8mb4_unicode_ci,
  `final_cta_button_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_cta_button_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_settings`
--

LOCK TABLES `homepage_settings` WRITE;
/*!40000 ALTER TABLE `homepage_settings` DISABLE KEYS */;
INSERT INTO `homepage_settings` VALUES (1,'VDC800','IS FUTURE OF DCs','VDC800 delivers enterprise-grade colocation and cloud connectivity from Nordic facilities engineered for uptime, security, and scale.','homepage/e1LV95WdfpyvHqL3nuX7UxiOtEC63wKcDuYxjurx.jpg','Explore Our Projects','/projects','View Services','/services','Where reliability meets precision','Our facilities are engineered for 99.999% uptime while maintaining a PUE below 1.2. Carrier-neutral connectivity, concurrent maintainability, and 24/7 NOC coverage make VDC800 the preferred partner for organisations committed to digital growth.','homepage/xofafrlMvYvsDaaGt1hGvJUUOObULaxCDFKU9CMz.jpg','Engineered for uptime. Built for scale.','From India  to Any Where, every VDC800 facility is designed for high-density workloads, efficient cooling, and operational transparency. We publish real-time availability metrics and hold ourselves accountable to enterprise SLAs.','homepage/xlouA7kQO2EmDpGeDXTVmCdXGFqWrbfjYvFuffqi.jpg','Our Operational Commitment','/about','Built for scale, designed for security','Tier IV+ architecture, biometric access controls, 24/7 NOC monitoring, and carrier-neutral connectivity to 40+ networks ensure your critical workloads are protected and always reachable.','homepage/ZKhkk8fQ5p7jCC18szZbDsAQmXFjK1jfTSaAmOlm.png','Ready to power your next chapter?','Speak with our infrastructure specialists about colocation, dedicated hosting, or custom enterprise solutions tailored to your requirements.','Get in Touch','/contact','2026-09-09 15:33:42','2026-09-15 13:51:01');
/*!40000 ALTER TABLE `homepage_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_statistics`
--

DROP TABLE IF EXISTS `homepage_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homepage_statistics` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_statistics`
--

LOCK TABLES `homepage_statistics` WRITE;
/*!40000 ALTER TABLE `homepage_statistics` DISABLE KEYS */;
INSERT INTO `homepage_statistics` VALUES (1,'165+','MW Capacity','Total power across europian facilities',1,1,'2026-09-09 15:33:42','2026-09-15 18:04:12'),(2,'24/7','NOC Coverage','Always-on operations support',2,1,'2026-09-09 15:33:42','2026-09-14 10:08:31'),(3,'99.999%','Uptime SLA','Tier IV availability guarantee',3,1,'2026-09-09 15:33:42','2026-09-15 18:03:49'),(4,'1.12','Average PUE','Industry-leading efficiency',4,1,'2026-09-09 15:33:42','2026-09-09 15:33:42');
/*!40000 ALTER TABLE `homepage_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homepage_testimonials`
--

DROP TABLE IF EXISTS `homepage_testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homepage_testimonials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quote` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` tinyint unsigned NOT NULL DEFAULT '5',
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homepage_testimonials`
--

LOCK TABLES `homepage_testimonials` WRITE;
/*!40000 ALTER TABLE `homepage_testimonials` DISABLE KEYS */;
INSERT INTO `homepage_testimonials` VALUES (1,'Priya Sharma','Chief Technology Officer','Mumbai FinTech Solutions','Mumbai, India','VDC800 gave us Nordic-grade colocation with latency that works for our European trading desks. Migration was smooth, and their team understood our RBI compliance requirements from day one.',5,1,1,'2026-09-09 15:33:49','2026-09-09 15:33:49'),(2,'Arjun Mehta','Head of Infrastructure','CloudScale India','Bengaluru, India','We needed carrier-neutral connectivity and enterprise SLAs for our SaaS platform. VDC800 delivered both — our uptime reporting to enterprise clients has never looked better.',5,2,1,'2026-09-09 15:33:49','2026-09-14 10:08:31'),(3,'Rekha Nair','VP Engineering','MediCare Digital','Chennai, India','Hosting healthcare workloads in a Tier III+ facility with 24/7 NOC monitoring gave our hospital partners the confidence they needed. VDC800\'s security posture exceeded our audit checklist.',5,3,1,'2026-09-09 15:33:49','2026-09-09 15:33:49'),(4,'Vikram Singh','Director of IT Operations','ShopKart India','New Delhi, India','During peak festival season, uptime is everything. VDC800\'s Oslo facility handled our traffic spikes without a single incident. Their support team responds within minutes, not hours.',5,4,1,'2026-09-09 15:33:49','2026-09-09 15:33:49'),(5,'Ananya Iyer','Head of Cloud Architecture','Hyderabad Tech Labs','Hyderabad, India','The direct cloud on-ramps to AWS and Azure saved us months of networking work. VDC800 feels like an extension of our engineering team — proactive, transparent, and deeply technical.',5,5,1,'2026-09-09 15:33:49','2026-09-09 15:33:49'),(6,'Rohan Kapoor','Chief Information Officer','Pune Manufacturing Group','Pune, India','We evaluated facilities across Europe and chose VDC800 for their operational transparency and biometric security. Our board was impressed by the quarterly SLA reporting they provide.',5,6,1,'2026-09-09 15:33:49','2026-09-14 10:08:31');
/*!40000 ALTER TABLE `homepage_testimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL DEFAULT '0',
  `alt_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_01_01_000001_add_is_admin_to_users_table',1),(5,'2026_01_01_000002_create_company_settings_table',1),(6,'2026_01_01_000003_create_site_settings_table',1),(7,'2026_01_01_000004_create_social_links_table',1),(8,'2026_01_01_000005_create_services_table',1),(9,'2026_01_01_000006_create_solutions_table',1),(10,'2026_01_01_000007_create_data_centres_table',1),(11,'2026_01_01_000008_create_data_centre_specifications_table',1),(12,'2026_01_01_000009_create_data_centre_features_table',1),(13,'2026_01_01_000010_create_data_centre_gallery_table',1),(14,'2026_01_01_000011_create_homepage_tables',1),(15,'2026_01_01_000012_create_about_tables',1),(16,'2026_01_01_000013_create_contact_submissions_table',1),(17,'2026_01_01_000014_create_media_table',1),(18,'2026_01_01_000015_create_homepage_hero_slides_table',1),(19,'2026_01_02_000001_add_category_to_services_table',1),(20,'2026_01_02_000002_create_blog_categories_table',1),(21,'2026_01_02_000003_create_blog_posts_table',1),(22,'2026_09_07_000001_add_slug_and_status_to_data_centres_table',1),(23,'2026_09_07_000002_create_homepage_testimonials_table',1),(24,'2026_09_07_000003_add_map_fields_to_company_settings_table',1),(25,'2026_09_07_000004_update_company_branding_favicon_paths',1),(26,'2026_03_10_000001_add_items_to_services_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `full_description` longtext COLLATE utf8mb4_unicode_ci,
  `items` json DEFAULT NULL,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `services_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (23,'Business & Advisory','business-advisory','Advisory Services','Define the opportunity, test the business case and create a practical path to capacity.','<p>Define the opportunity, test the business case and create a practical path to capacity.</p>\r\n<h2>What we deliver</h2>\r\n<h3>Market &amp; Capacity Assessment</h3><p>Assess market demand, supply, pricing and competitive dynamics to identify where capacity can be developed or accessed.</p><h3>Feasibility Studies</h3><p>Test technical, commercial and development assumptions before significant capital or time is committed.</p><h3>Site Evaluation</h3><p>Evaluate power availability, connectivity, land, utilities, approvals and other factors that influence site viability.</p><h3>Development Strategy</h3><p>Translate the opportunity into a phased development plan covering capacity, infrastructure, partners and execution priorities.</p><h3>Business Planning</h3><p>Build the operating and commercial framework required to take a data center opportunity from concept toward implementation.</p>\r\n<h2>Why it matters</h2>\r\n<p>Data center and AI infrastructure decisions carry significant commercial, technical and execution risk. Strategy & Advisory brings structured analysis and practical guidance so stakeholders can move from opportunity to action with greater confidence.</p>\r\n<p>Our multidisciplinary team combines commercial understanding, engineering depth and delivery experience across data center strategy, feasibility studies, site evaluation, development strategy, business planning. We work alongside investors, developers and operators to align assumptions, surface risks early and define clear next steps.</p>\r\n<h2>How we work</h2>\r\n<p>Engagements typically begin with a focused discovery conversation to understand your objectives, constraints and timeline. We then scope the work, assign the right specialists and deliver decision-ready outputs — whether that is a feasibility assessment, due diligence report, design recommendation or procurement plan.</p>\r\n<p>Where projects continue into engineering, procurement or demand development, we maintain continuity so commercial and technical decisions stay connected throughout the journey.</p>\r\n<h2>Get started</h2>\r\n<p>Whether you are evaluating a new data center opportunity, assessing an investment, designing high-density infrastructure or connecting capacity with qualified demand, we can help identify the next critical step. <a href=\"/contact\">Contact us</a> to discuss your requirements.</p>','[{\"title\": \"Market & Capacity Assessment\", \"description\": \"Assess market demand, supply, pricing and competitive dynamics to identify where capacity can be developed or accessed.\"}, {\"title\": \"Feasibility Studies\", \"description\": \"Test technical, commercial and development assumptions before significant capital or time is committed.\"}, {\"title\": \"Site Evaluation\", \"description\": \"Evaluate power availability, connectivity, land, utilities, approvals and other factors that influence site viability.\"}, {\"title\": \"Development Strategy\", \"description\": \"Translate the opportunity into a phased development plan covering capacity, infrastructure, partners and execution priorities.\"}, {\"title\": \"Business Planning\", \"description\": \"Build the operating and commercial framework required to take a data center opportunity from concept toward implementation.\"}]','services/UnD8VbFrZdfQ6hcrAyK7s1SWve64m6eUBGrKzpMN.png','compass','Start a Conversation','/contact','Strategy & Advisory | VDC800','Explore Strategy & Advisory with VDC800: data center strategy, feasibility studies, site evaluation. Nordic Tier III+ facilities, 99.999% uptime, 99...','images/services/service-1.jpg',1,'published','2026-09-10 12:11:16','2026-09-14 14:17:40'),(24,'Investment & Due Diligence','investment-due-diligence','Advisory Services','Give investors and decision-makers the technical and financial clarity needed to commit capital.','<p>Give investors and decision-makers the technical and financial clarity needed to commit capital.</p>\r\n<h2>What we deliver</h2>\r\n<h3>Detailed Project Reports</h3><p>Structure project assumptions, scope, phasing, costs and implementation plans into a decision-ready project report.</p><h3>Financial Analysis</h3><p>Evaluate CAPEX, operating costs, revenue assumptions and project economics to understand investment potential.</p><h3>Technical Due Diligence</h3><p>Review power, cooling, electrical, mechanical, network and site infrastructure to identify technical risks and gaps.</p><h3>CAPEX Benchmarking</h3><p>Test major cost assumptions against project scope, capacity and market benchmarks to improve capital planning.</p><h3>Investment Decision Support</h3><p>Convert technical findings into clear commercial implications, risks, opportunities and decision points.</p>\r\n<h2>Why it matters</h2>\r\n<p>Data center and AI infrastructure decisions carry significant commercial, technical and execution risk. Investment & Due Diligence brings structured analysis and practical guidance so stakeholders can move from opportunity to action with greater confidence.</p>\r\n<p>Our multidisciplinary team combines commercial understanding, engineering depth and delivery experience across investment due diligence, financial analysis, technical due diligence, CAPEX benchmarking, project reports. We work alongside investors, developers and operators to align assumptions, surface risks early and define clear next steps.</p>\r\n<h2>How we work</h2>\r\n<p>Engagements typically begin with a focused discovery conversation to understand your objectives, constraints and timeline. We then scope the work, assign the right specialists and deliver decision-ready outputs — whether that is a feasibility assessment, due diligence report, design recommendation or procurement plan.</p>\r\n<p>Where projects continue into engineering, procurement or demand development, we maintain continuity so commercial and technical decisions stay connected throughout the journey.</p>\r\n<h2>Get started</h2>\r\n<p>Whether you are evaluating a new data center opportunity, assessing an investment, designing high-density infrastructure or connecting capacity with qualified demand, we can help identify the next critical step. <a href=\"/contact\">Contact us</a> to discuss your requirements.</p>','[{\"title\": \"Detailed Project Reports\", \"description\": \"Structure project assumptions, scope, phasing, costs and implementation plans into a decision-ready project report.\"}, {\"title\": \"Financial Analysis\", \"description\": \"Evaluate CAPEX, operating costs, revenue assumptions and project economics to understand investment potential.\"}, {\"title\": \"Technical Due Diligence\", \"description\": \"Review power, cooling, electrical, mechanical, network and site infrastructure to identify technical risks and gaps.\"}, {\"title\": \"CAPEX Benchmarking\", \"description\": \"Test major cost assumptions against project scope, capacity and market benchmarks to improve capital planning.\"}, {\"title\": \"Investment Decision Support\", \"description\": \"Convert technical findings into clear commercial implications, risks, opportunities and decision points.\"}]','services/GdqL6tbV2t2pHI7zSMQMesZX1cdScyGgrYiWxRwQ.webp','chart-line','Start a Conversation','/contact','Investment & Due Diligence | VDC800','Explore Investment & Due Diligence with VDC800: investment due diligence, financial analysis, technical due diligence. Nordic Tier III+ facilities, 100% re...','images/services/service-2.jpg',2,'published','2026-09-10 12:11:16','2026-09-14 14:23:55'),(25,'Engineering & Design','engineering-design','Advisory Services','Translate compute requirements into resilient power, cooling and infrastructure solutions.','<p>Translate compute requirements into resilient power, cooling and infrastructure solutions.</p>\n<h2>What we deliver</h2>\n<h3>Power Infrastructure</h3><p>Define utility, generation, substation and distribution strategies aligned with required capacity and resilience.</p><h3>Electrical Systems</h3><p>Develop electrical architecture covering MV/LV distribution, UPS, switchgear, busways and critical power paths.</p><h3>Cooling &amp; Mechanical</h3><p>Assess cooling architecture and mechanical systems for conventional and high-density compute environments.</p><h3>AI &amp; High-Density Infrastructure</h3><p>Plan infrastructure around high-density GPU deployments, rack power, thermal loads and associated network requirements.</p><h3>Design Coordination</h3><p>Coordinate technical inputs across disciplines so engineering decisions remain aligned with the commercial and delivery objectives.</p>\n<h2>Why it matters</h2>\n<p>Data center and AI infrastructure decisions carry significant commercial, technical and execution risk. Engineering & Design brings structured analysis and practical guidance so stakeholders can move from opportunity to action with greater confidence.</p>\n<p>Our multidisciplinary team combines commercial understanding, engineering depth and delivery experience across power infrastructure, electrical systems, cooling design, AI infrastructure, high-density compute. We work alongside investors, developers and operators to align assumptions, surface risks early and define clear next steps.</p>\n<h2>How we work</h2>\n<p>Engagements typically begin with a focused discovery conversation to understand your objectives, constraints and timeline. We then scope the work, assign the right specialists and deliver decision-ready outputs — whether that is a feasibility assessment, due diligence report, design recommendation or procurement plan.</p>\n<p>Where projects continue into engineering, procurement or demand development, we maintain continuity so commercial and technical decisions stay connected throughout the journey.</p>\n<h2>Get started</h2>\n<p>Whether you are evaluating a new data center opportunity, assessing an investment, designing high-density infrastructure or connecting capacity with qualified demand, we can help identify the next critical step. <a href=\"/contact\">Contact us</a> to discuss your requirements.</p>','[{\"title\": \"Power Infrastructure\", \"description\": \"Define utility, generation, substation and distribution strategies aligned with required capacity and resilience.\"}, {\"title\": \"Electrical Systems\", \"description\": \"Develop electrical architecture covering MV/LV distribution, UPS, switchgear, busways and critical power paths.\"}, {\"title\": \"Cooling & Mechanical\", \"description\": \"Assess cooling architecture and mechanical systems for conventional and high-density compute environments.\"}, {\"title\": \"AI & High-Density Infrastructure\", \"description\": \"Plan infrastructure around high-density GPU deployments, rack power, thermal loads and associated network requirements.\"}, {\"title\": \"Design Coordination\", \"description\": \"Coordinate technical inputs across disciplines so engineering decisions remain aligned with the commercial and delivery objectives.\"}]','images/services/service-3.jpg','blueprint','Start a Conversation','/contact','Engineering & Design | VDC800','Explore Engineering & Design with VDC800: power infrastructure, electrical systems, cooling design. Nordic Tier III+ facilities, 99.999% uptime, 99....','images/services/service-3.jpg',3,'published','2026-09-10 12:11:16','2026-09-14 10:08:31'),(26,'Procurement & Execution','procurement-execution','Advisory Services','Help clients source the right equipment and coordinate the path from technical design to delivery.','<p>Help clients source the right equipment and coordinate the path from technical design to delivery.</p>\n<h2>What we deliver</h2>\n<h3>Vendor Evaluation</h3><p>Identify and assess vendors against technical capability, commercial fit, delivery capacity and project requirements.</p><h3>Technical Compliance</h3><p>Review technical offers and specifications to ensure proposed equipment meets the defined performance requirements.</p><h3>Equipment Sourcing</h3><p>Support sourcing of critical electrical, mechanical, cooling and data center infrastructure equipment.</p><h3>Procurement Support</h3><p>Assist with bid comparisons, technical clarifications, commercial evaluation and procurement decision-making.</p><h3>Project Coordination</h3><p>Coordinate stakeholders, suppliers and technical teams to keep key delivery activities aligned with project priorities.</p>\n<h2>Why it matters</h2>\n<p>Data center and AI infrastructure decisions carry significant commercial, technical and execution risk. Procurement & Execution brings structured analysis and practical guidance so stakeholders can move from opportunity to action with greater confidence.</p>\n<p>Our multidisciplinary team combines commercial understanding, engineering depth and delivery experience across vendor evaluation, equipment sourcing, procurement support, technical compliance, project coordination. We work alongside investors, developers and operators to align assumptions, surface risks early and define clear next steps.</p>\n<h2>How we work</h2>\n<p>Engagements typically begin with a focused discovery conversation to understand your objectives, constraints and timeline. We then scope the work, assign the right specialists and deliver decision-ready outputs — whether that is a feasibility assessment, due diligence report, design recommendation or procurement plan.</p>\n<p>Where projects continue into engineering, procurement or demand development, we maintain continuity so commercial and technical decisions stay connected throughout the journey.</p>\n<h2>Get started</h2>\n<p>Whether you are evaluating a new data center opportunity, assessing an investment, designing high-density infrastructure or connecting capacity with qualified demand, we can help identify the next critical step. <a href=\"/contact\">Contact us</a> to discuss your requirements.</p>','[{\"title\": \"Vendor Evaluation\", \"description\": \"Identify and assess vendors against technical capability, commercial fit, delivery capacity and project requirements.\"}, {\"title\": \"Technical Compliance\", \"description\": \"Review technical offers and specifications to ensure proposed equipment meets the defined performance requirements.\"}, {\"title\": \"Equipment Sourcing\", \"description\": \"Support sourcing of critical electrical, mechanical, cooling and data center infrastructure equipment.\"}, {\"title\": \"Procurement Support\", \"description\": \"Assist with bid comparisons, technical clarifications, commercial evaluation and procurement decision-making.\"}, {\"title\": \"Project Coordination\", \"description\": \"Coordinate stakeholders, suppliers and technical teams to keep key delivery activities aligned with project priorities.\"}]','images/services/service-4.jpg','package','Start a Conversation','/contact','Procurement & Execution | VDC800','Explore Procurement & Execution with VDC800: vendor evaluation, equipment sourcing, procurement support. Nordic Tier III+ facilities, 99.999% uptime...','images/services/service-4.jpg',4,'published','2026-09-10 12:11:16','2026-09-14 10:08:31'),(27,'Demand Generation','demand-generation','Advisory Services','Help data centers connect with qualified potential clients for colocation, GPU capacity and Build to Suit opportunities.','<p>Help data centers connect with qualified potential clients for colocation, GPU capacity and Build to Suit opportunities.</p>\n<h2>What we deliver</h2>\n<h3>Colocation Demand</h3><p>Identify and connect data centers with enterprises and digital businesses looking for reliable colocation capacity.</p><h3>GPU Capacity Demand</h3><p>Connect available AI compute capacity with organizations seeking GPU infrastructure for training, inference and other workloads.</p><h3>Build to Suit Opportunities</h3><p>Help data center developers identify potential customers with requirements for dedicated or purpose-built infrastructure.</p><h3>Client Qualification</h3><p>Understand prospective clients&#039; capacity, power, density, location, timeline and commercial requirements to improve opportunity quality.</p><h3>Opportunity Development</h3><p>Support introductions and commercial discussions that help move qualified data center demand toward actionable opportunities.</p>\n<h2>Why it matters</h2>\n<p>Data center and AI infrastructure decisions carry significant commercial, technical and execution risk. Demand Generation brings structured analysis and practical guidance so stakeholders can move from opportunity to action with greater confidence.</p>\n<p>Our multidisciplinary team combines commercial understanding, engineering depth and delivery experience across colocation demand, GPU capacity, build to suit, client qualification, opportunity development. We work alongside investors, developers and operators to align assumptions, surface risks early and define clear next steps.</p>\n<h2>How we work</h2>\n<p>Engagements typically begin with a focused discovery conversation to understand your objectives, constraints and timeline. We then scope the work, assign the right specialists and deliver decision-ready outputs — whether that is a feasibility assessment, due diligence report, design recommendation or procurement plan.</p>\n<p>Where projects continue into engineering, procurement or demand development, we maintain continuity so commercial and technical decisions stay connected throughout the journey.</p>\n<h2>Get started</h2>\n<p>Whether you are evaluating a new data center opportunity, assessing an investment, designing high-density infrastructure or connecting capacity with qualified demand, we can help identify the next critical step. <a href=\"/contact\">Contact us</a> to discuss your requirements.</p>','[{\"title\": \"Colocation Demand\", \"description\": \"Identify and connect data centers with enterprises and digital businesses looking for reliable colocation capacity.\"}, {\"title\": \"GPU Capacity Demand\", \"description\": \"Connect available AI compute capacity with organizations seeking GPU infrastructure for training, inference and other workloads.\"}, {\"title\": \"Build to Suit Opportunities\", \"description\": \"Help data center developers identify potential customers with requirements for dedicated or purpose-built infrastructure.\"}, {\"title\": \"Client Qualification\", \"description\": \"Understand prospective clients\' capacity, power, density, location, timeline and commercial requirements to improve opportunity quality.\"}, {\"title\": \"Opportunity Development\", \"description\": \"Support introductions and commercial discussions that help move qualified data center demand toward actionable opportunities.\"}]','images/services/service-5.jpg','users','Start a Conversation','/contact','Demand Generation | VDC800','Explore Demand Generation with VDC800: colocation demand, GPU capacity, build to suit. Nordic Tier III+ facilities, 99.999% uptime, 99.999% uptime S...','images/services/service-5.jpg',5,'published','2026-09-10 12:11:16','2026-09-14 10:08:31');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('asobUp5krbt8BVNCmo5Soq4icbD9sHcBHTKjaD29',NULL,'182.77.68.208','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Mobile Safari/537.36','eyJfdG9rZW4iOiJWSXNtMXZVWW1rTGlGZ1h3VTUzZVJJNnA4cXN2Q05wRmVLSkJyUGVTIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791283369),('E8BkQCcvC7WHfO8Xm5WAdgww62nkfPLBn8ImLSrh',NULL,'104.168.53.148','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36','eyJfdG9rZW4iOiJJNTlyOVJLWGlyVE9TSk03T3ZQQjRMQ3RyeXdHT0wzWnBaeEpTWXlzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791278881),('ElQOrkOUIKMBWhNE0bwVjFM1dr1srBx131gBs6S1',NULL,'43.157.142.101','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJKc1NZd3VNdWEwOXpJVDg1R3hLemJtWFo1aWRLTVU1MGhFUXpXQWUyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791281190),('hVrCrtB9ygZgROan0DhqUxE5g1K6lfuSObsegKSN',NULL,'43.135.145.117','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJjbEdnNTdsQnFQU2RnZWc1akZlOUVVZHBreElhUVNzdm5FVExSanJwIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791281057),('MeUeQwIirqDKLDwSjnGOQwUEHn3L1i8CUjqLX7Oz',NULL,'49.51.73.183','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiIxSFJsNGM5Q2xKdGdUTDA1UHY0VUx2WTRESVVza3dORjNjZUhZYThyIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791278283),('N40UXg0TdysxV4KnHR9AuWicCCL654WHKvUExZEk',NULL,'198.11.177.243','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJCYmU5NjMyV1dVR3pKMUdQWVhobGtmOHNCSmgxR2pHVFVPd0FYRWhzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791281391),('pdAShyCTeQGTkFM2dOqWuWgxMZFexuUSYunNKvtH',NULL,'43.135.115.233','Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1','eyJfdG9rZW4iOiJQVlRGMUE0SUhpc2t4bVAxeUZFeDh4VlFTTlZma3k2cE9ZTmx4emh5IiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791281635),('ThVXVok4A0zoiO7Z0mS5qRHmu6rAWgP7wsbDrGVQ',NULL,'198.235.24.101','Hello from Palo Alto Networks, find out more about our scans in https://docs-cortex.paloaltonetworks.com/r/1/Cortex-Xpanse/Scanning-activity','eyJfdG9rZW4iOiJnY3hOa1E4b0EwOEoxSlVRa0wwMVpGdGYxTVE1ODFlREFnWkhBV01FIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791281775),('UMzSldWSa9OmIxoNo48w97kziIU54wLFUnbeRbDn',NULL,'54.204.62.163','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot) Chrome/119.0.6045.214 Safari/537.36','eyJfdG9rZW4iOiJmZzFXaEhDMEoySHc5YWtzZmtQOFlINWlLMmxTWkFEUTBxWVdMMVBnIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbVwvYmxvZyIsInJvdXRlIjoiYmxvZy5pbmRleCJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791276658),('vGFWm5YWpvSwL2iIFG4IID7db0rGvbrHiQr764sR',NULL,'182.77.68.208','WhatsApp/2.23.20.0','eyJfdG9rZW4iOiJ5SDV3UUs0OEZtbFJQalJmOWFyUzBpNE9QOVFmTHhwYkZuUFZCdkRBIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbSIsInJvdXRlIjoiaG9tZSJ9LCJfZmxhc2giOnsib2xkIjpbXSwibmV3IjpbXX19',1791283426),('VMoCA2uibgxx2vIEFnQ2x5CKrvmJXPe13fKu0RIf',NULL,'54.235.172.96','Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; Amazonbot/0.1; +https://developer.amazon.com/support/amazonbot) Chrome/119.0.6045.214 Safari/537.36','eyJfdG9rZW4iOiJDejE4ZnVERTAwdHNxS3d1RGlpalVRbjJNTHNZWVg0NVZVckJieGwzIiwiX3ByZXZpb3VzIjp7InVybCI6Imh0dHBzOlwvXC93d3cudmRjODAwLmNvbVwvc2VydmljZXNcL2RlbWFuZC1nZW5lcmF0aW9uIiwicm91dGUiOiJzZXJ2aWNlcy5zaG93In0sIl9mbGFzaCI6eyJvbGQiOltdLCJuZXciOltdfX0=',1791284046);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `website_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_page_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_meta_description` text COLLATE utf8mb4_unicode_ci,
  `default_keywords` text COLLATE utf8mb4_unicode_ci,
  `google_analytics_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_tag_manager_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UTC',
  `default_language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'VDC800','https://www.vdc800.com','Data Center Planning, Design & Build Solutions | VDC800','VDC800 provides end-to-end data center planning, design, engineering, build, commissioning and infrastructure support for secure, scalable and reliable facilities.','data centre, nordic, colocation, cloud connectivity, enterprise hosting',NULL,NULL,'Europe/Oslo','en',NULL,'2026-09-09 15:33:42','2026-09-14 15:13:43');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `social_links`
--

DROP TABLE IF EXISTS `social_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `social_links` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `platform` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `social_links`
--

LOCK TABLES `social_links` WRITE;
/*!40000 ALTER TABLE `social_links` DISABLE KEYS */;
INSERT INTO `social_links` VALUES (1,'LinkedIn','https://linkedin.com/company/VDC800','linkedin',1,1,'2026-09-09 15:33:42','2026-09-09 15:33:42'),(2,'X','https://x.com/VDC800','twitter',1,2,'2026-09-09 15:33:42','2026-09-09 15:33:42'),(3,'Facebook','https://facebook.com/VDC800','facebook',1,3,'2026-09-09 15:33:42','2026-09-09 15:33:42'),(4,'Instagram','https://instagram.com/VDC800','instagram',1,4,'2026-09-09 15:33:42','2026-09-09 15:33:42'),(5,'GitHub','https://github.com/VDC800','github',1,5,'2026-09-09 15:33:42','2026-09-09 15:33:42'),(6,'YouTube','https://youtube.com/@VDC800','youtube',1,6,'2026-09-09 15:33:42','2026-09-09 15:33:42');
/*!40000 ALTER TABLE `social_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `solutions`
--

DROP TABLE IF EXISTS `solutions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `solutions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `benefits` json DEFAULT NULL,
  `cta_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cta_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `solutions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `solutions`
--

LOCK TABLES `solutions` WRITE;
/*!40000 ALTER TABLE `solutions` DISABLE KEYS */;
/*!40000 ALTER TABLE `solutions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator','support@vdc800.com',NULL,'$2y$12$ZUeO0e/H4/W6WUNLlPOEAeub5kGFCll4k2WltFshaj6qe8.VmR9vS',1,'qNcKHU873DXXcUW7c7rDfuWEhZOf0I05rnrv4HqwSFtfXvbHcwhHSheZQDLg','2026-09-09 15:33:42','2026-09-09 16:22:36');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'vdc800'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-06 11:28:49
